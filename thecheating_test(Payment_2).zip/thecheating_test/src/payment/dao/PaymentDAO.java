package payment.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import payment.dto.AccCheckDTO;
import payment.dto.AccUserDTO;
import payment.dto.HistInput;
import payment.dto.HistOutput;

public class PaymentDAO {

	DataSource ds;
	
	/** DB 연결을 위한 메서드**/
	public PaymentDAO(){
		try {
			Context ctx =new InitialContext();
			ds=(DataSource) ctx.lookup("java:comp/env/jdbc/orcl");
			System.out.println("ds : "+ds);
		} catch (NamingException e) {
			System.out.println("Connect ERR"+e.getMessage());
		}
	}	// public PaymentDAO() END
	
	/*
	 *  1. 회원가입시 이름을 통해 전체 맴버 계좌테이블과 회원개인용 테이블 생성을 위한 메서드들
	 *  
	 *  	1) public ArrayList<AccCheckDTO> checklist(String holder)
	 *  		stats값이 1일 경우 : 2)번 3)번으로 진행한다.
	 *  		1이 아닐 경우 : error 메시지를 띄워 휴면/정지중인 계좌는 등록할수 없다고 한다.
	 *  			=> 컨트롤러에서 메시지내용을 객체로 전달하여 화면에 뿌려주기 
	 *  
	 *  	2)  public void joinMemAcc(String user_name, String user_account, int user_bankname, int user_balance) 실행
	 *  		이때 input값들은 1)에서 리턴해주는 list에서 getter를 이용해 넣어준다.
	 *  
	 *  	3)  public void accountUserInsert (String user_name, String user_account, int user_bankname, int user_balance)
	 *  		2) 와 같이 1)에서 리턴해주는 list값을 받아서 input.
	 */	
	
	
	/** 회원가입시 전체 회원 계좌 테이블 생성을 위한 사전준비 계좌의 값 찾아오기**/
	public ArrayList<AccCheckDTO> checklist(String holder){
		ArrayList<AccCheckDTO> list = new ArrayList<AccCheckDTO>();
		try {
			String sql="SELECT bank_name, account_num, balance, stats FROM acc_check where holder = "+holder;
			Connection con = ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				AccCheckDTO data = new AccCheckDTO();
				data.setBank_name(rs.getInt("bank_name"));
				data.setAccount_num(rs.getString("account_num"));
				data.setBalance(rs.getInt("balance"));
				data.setStats(rs.getInt("stats"));	// stats이 1번일 경우만 등록
				list.add(data);
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("checklist ERR : "+ e.getMessage());
		}
		return list;
	}	// public ArrayList<BoardDTO> list() END
	
	/** 전체 회원 계좌 등록 매서드 **/
	public void joinMemAcc(String name, String account_num, int balance, int bank_name){
		String sql="INSERT INTO acc_total (seq_total, name, account_num, balance, stats, reg_date, bank_name) "
				+" VALUES (seq_total.Nextval, ?, ?, ?, 1, now(), ?)";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt =con.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, account_num);
			pstmt.setInt(3,  balance);
			pstmt.setInt(4, bank_name);
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("joinMemAcc ERR : " + e.getMessage());
		}
	}	// public void create(String name, int account_type, int balance) END

	
	/* 회원가입시 사용자 계좌 테이블에 insert */
	public void accountUserInsert (String user_name, String user_account, int user_bankname, int user_balance){
		String sql="INSERT INTO acc_user (seq_user, user_name, user_account, user_bankname, user_balance, user_stats) "
				+" VALUES (seq_user.Nextval, ?, ?, ?, ?, 1, 0)";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt =con.prepareStatement(sql);
			pstmt.setString(1, user_name);
			pstmt.setString(2, user_account);
			pstmt.setInt(3,  user_bankname);
			pstmt.setInt(4, user_balance);
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("accountUesrInsert ERR : "+e.getMessage());
		}
	}	// public void accountUserInsert (String user_name, String user_account, int user_bankname, int user_balance)
	
	
	/* 
	 *  2. 결제
	 *  	1) 채팅방에서 리더의 계좌를 대표 계좌로 만들어 놓기
	 *  		결제용 계좌 찾기 메서드를 통해 리더의 계좌 정보 찾아놓은뒤
	 *  
	 *  	2) 단톡방 결제용 테이블에 넣어준다. 이때 결제금액까지 같이 넣어 둔다.
	 *  
	 */
	
	/* 결제용 계좌 찾기 */
	public ArrayList<AccUserDTO> paymentAccountSelect(String chat_leader){
		ArrayList<AccUserDTO> list = new ArrayList<AccUserDTO>();
		try {
			String sql="SELECT USER_ACCOUNT, USER_BANKNAME FROM ACC_USER WHERE USER_NAME = "+chat_leader;
			Connection con = ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				AccUserDTO data = new AccUserDTO();
				data.setUser_account(rs.getString("user_account"));
				data.setUser_bankname(rs.getInt("user_bankname"));
				list.add(data);
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("paymentAccountSelect  ERR : "+e.getMessage());
		}
		return list;
	}	// public ArrayList<AccUserDTO> paymentAccountSelect(String chat_leader)
	
	/*	단톡방 테이블 생성 */
	public void dutchMoneySelect (int chat_idx, String chat_leader, String leader_account, int leader_banknum, int payment){
		String sql="INSERT INTO dutch_money (chat_idx, chat_leader, leader_account, leader_banknum, payment) "
				+" VALUES (?, ?, ?, ?, ? )";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt =con.prepareStatement(sql);
			pstmt.setInt(1, chat_idx);
			pstmt.setString(2, chat_leader);
			pstmt.setString(3, leader_account);
			pstmt.setInt(4,  leader_banknum);
			pstmt.setInt(5, payment);
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("dutchMoneySelect ERR : " + e.getMessage());
		}		
	} // public void dutchMoneySelect (String chat_leader, String leader_account, int leader_banknum, int payment) END
	
	/* 사용자 계좌 잔액 조회 메서드 */
	public int userBalanceSelect(String user_name, String account_num, int bank_num) {
		int balance = 0;
		try {
			String sql="SELECT USER_BALANCE FROM ACC_USER WHERE USER_NAME = ? AND ACCOUNT_NUM = ? AND BANK_NUM = ?";
			Connection con = ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, user_name);
			pstmt.setString(2, account_num);
			pstmt.setInt(3, bank_num);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				balance = rs.getInt("balance");
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("userBalanceSelect ERR : "+e.getMessage());
		}
		return balance;
	}
	
	/* 입금자 계좌 출금 처리*/
	public void depositMyaccountI(String user_name, String account_num, int bank_num, int withdraw){	// 수정 할것
		String sql="update acc_user set user_usedate = now(), balance = ? where account_num =? and user_name = ? AND user_bankname =?";
		try {
			Connection con = ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, this.userBalanceSelect(user_name, account_num, bank_num)-withdraw);
			pstmt.setString(2, account_num);
			pstmt.setString(3, user_name);
			pstmt.setInt(4, bank_num);
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("depositMyaccountI ERR : "+e.getMessage());
		}
	}	// public void depositMyaccountI(String user_name, String account_num, int bank_num, int withdraw); END
	
	/* 출금 기록에 저장 */
	public void histOutputInsert (String output_account, String receiver, int withdraw, String memo){
		String sql="INSERT INTO hist_output (seq_output, output_account, withdraw, o_resdate, receiver, memo) "
				+" VALUES (seq_output.Nextval, ?, ?, ?, now(), ? )";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt =con.prepareStatement(sql);
			pstmt.setString(1, output_account);
			pstmt.setInt(2, withdraw);
			pstmt.setString(3,  receiver);
			pstmt.setString(4, memo);
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("histOutputInsert ERR : " + e.getMessage());
		}		
	} // public void histOutputInsert (String output_account, String receiver, int withdraw, String memo) END
	
	/* 단톡방 테이블에서의 입금 처리 메서드 */
	// ################################################
	// 수정필요 1) dutch_money테이블에 저장 방식에 대한 재고 필요
	// #################################################
	public void dutchMoneyInput (int chat_idx, String chat_leader, String leader_account, int leader_banknum, String sender, String sender_account, int sender_banknum, int deposit, String depo_date){
		String sql1="update acc_user set user_usedate = now(), balance = ? where account_num =? and user_name = ? and user_bankname = ?";
		String sql2 = ""; // dutch_money 테이블에 값 넣을 쿼리문 쓸 예정, 조인을 통해 넣을지 고민중
		try {
			Connection con = ds.getConnection();
			PreparedStatement pstmt1 = con.prepareStatement(sql1);
			pstmt1.setInt(1, this.userBalanceSelect(chat_leader, leader_account, leader_banknum)+ deposit);
			pstmt1.setString(2, leader_account);
			pstmt1.setString(3, chat_leader);
			pstmt1.setInt(4, leader_banknum);
			pstmt1.executeUpdate();
			pstmt1.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("dutchMoneyInput ERR : " + e.getMessage());
		}
	}
	
	/* 입금 기록에 저장 */
	public void histInputInsert (String chat_leader, String input_account, int leader_banknum, String sender, int deposit, String memo){
		String sql="INSERT INTO hist_input (seq_input, input_account, deposit, i_resdate, sender, balance, memo) "
				+" VALUES (seq_input.Nextval, ?, ?, now(), ?, ?, ? )";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt =con.prepareStatement(sql);
			pstmt.setString(1, input_account);
			pstmt.setInt(2, deposit);
			pstmt.setString(3,  sender);
			pstmt.setInt(4, this.userBalanceSelect(chat_leader, input_account, leader_banknum)); 
			// 입금이 된 이후의 잔액을 보여주는 것이므로 현재의 매서드는 입출금 메서드 이후 진행되어야함.
			pstmt.setString(5, memo); 
			// memo 부분은 입력 폼에서 Null이 들어와도 되지만 이 메서드를 처리하기 전에
			// 논리문을 통하여 input으로 주거나 null일 경우 "-" 값을 input으로 넣어주면 된다.
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("histInputInsert ERR : " + e.getMessage());
		}		
	} // public void histOutputInsert (String output_account, String receiver, int withdraw, String memo) END
	
	
	/*
	 * 기록 조회 메서드
	 * 
	 * 기록 조회를 할 때 기본적으로 결제 취소 건에 대해서는 보여주지 않기 위해 stats을 따로 넣었다
	 * stats = 1 일 경우 취소 하지 않고 승인된 결제들이다.
	 * stats = 2 의 계좌의 정지 혹은 해지로 사용되지는 않지만, 내역을 보여주기 위한 것들
	 * stats = 3 은 경우 확정 되지 않은 결제
	 * stats 값에 대한 내용은 아직 확정은 아니지만 메서드 생성 하는 과정 중 
	 * 떠오르는 대로 만들어 놓았기 때문에 확인할 필요성이 있다.
	 * ########################################
	 * 
	 * 1. 입금 기록 조회 메서드 public ArrayList<HistInput> inputHistory(String user_name, String user_account, int user_bankname, int stats)
	 * 2. 출금 기록 조회 메서드 public ArrayList<HistOutput> outputHistory(String user_name, String user_account, int user_bankname, int stats)
	 */
	
	
	/* 입금 기록 조회 메서드 */
	public ArrayList<HistInput> inputHistory(String user_name, String user_account, int user_bankname, int stats){
		String sql = "SELECT (sender, deposit, memo, input_account, to_char(i_resdate, 'yyyy-mm-dd hh24:mi:ss')) FROM HistInput WHERE user_name = ? AND user_account = ? AND user_bankname = ? AND stats = ?";
		ArrayList<HistInput> histInList = new ArrayList<HistInput>();
		try{
			Connection con = ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, user_name);
			pstmt.setString(2, user_account);
			pstmt.setInt(3, user_bankname);
			pstmt.setInt(4, stats);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				HistInput histInput = new HistInput();
				histInput.setSender(rs.getString("sender"));
				histInput.setDeposit(rs.getInt("deposit"));
				histInput.setMemo(rs.getString("memo"));
				histInput.setInput_account(rs.getString("input_account"));
				histInput.setI_resdate(rs.getString("i_resdate"));
				histInList.add(histInput);
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("inputHistory ERR : "+e.getMessage());
		}
		return histInList;
	} // public ArrayList<HistInput> inputHistory(String user_name, String user_account, int user_bankname, int stats) END
	
	
	/* 출금 조회 메서드*/
	public ArrayList<HistOutput> outputHistory(String user_name, String user_account, int user_bankname, int stats){
		String sql = "SELECT (output_account, withdraw, memo, reciever, to_char(o_resdate, 'yyyy-mm-dd hh24:mi:ss')) FROM HistOutput WHERE user_name = ? AND user_account = ? AND user_bankname = ? AND stats = ?";
		ArrayList<HistOutput> histInList = new ArrayList<HistOutput>();
		try{
			Connection con = ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, user_name);
			pstmt.setString(2, user_account);
			pstmt.setInt(3, user_bankname);
			pstmt.setInt(4, stats);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				HistOutput histOutput = new HistOutput();
				histOutput.setReciever(rs.getString("reciever"));
				histOutput.setWithdraw(rs.getInt("withdraw"));
				histOutput.setMemo(rs.getString("memo"));
				histOutput.setOutput_account(rs.getString("output_account"));
				histOutput.setO_resdate(rs.getString("o_resdate"));
				histInList.add(histOutput);
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("outputHistory ERR : "+e.getMessage());
		}
		return histInList;
	} // public ArrayList<HistOutput> outputHistory(String user_name, String user_account, int user_bankname, int stats)
}
