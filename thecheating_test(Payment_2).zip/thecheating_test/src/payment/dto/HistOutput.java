package payment.dto;

public class HistOutput {
	
	private String user_name;
	private String user_account;
	private int user_bankname;
	private int seq_output;
	private String output_account;
	private int withdraw;
	private String o_resdate;
	private String reciever;
	private int balance;
	private int stats;
	private String memo;
	
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_account() {
		return user_account;
	}
	public void setUser_account(String user_account) {
		this.user_account = user_account;
	}
	public int getUser_bankname() {
		return user_bankname;
	}
	public void setUser_bankname(int user_bankname) {
		this.user_bankname = user_bankname;
	}
	public int getSeq_output() {
		return seq_output;
	}
	public void setSeq_output(int seq_output) {
		this.seq_output = seq_output;
	}
	public String getOutput_account() {
		return output_account;
	}
	public void setOutput_account(String output_account) {
		this.output_account = output_account;
	}
	public int getWithdraw() {
		return withdraw;
	}
	public void setWithdraw(int withdraw) {
		this.withdraw = withdraw;
	}
	public String getO_resdate() {
		return o_resdate;
	}
	public void setO_resdate(String o_resdate) {
		this.o_resdate = o_resdate;
	}
	public String getReciever() {
		return reciever;
	}
	public void setReciever(String reciever) {
		this.reciever = reciever;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public int getStats() {
		return stats;
	}
	public void setStats(int stats) {
		this.stats = stats;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
}
