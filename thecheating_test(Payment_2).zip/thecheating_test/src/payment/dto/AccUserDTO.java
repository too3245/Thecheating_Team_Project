package payment.dto;

public class AccUserDTO {
	
	private int seq_user;
	private String user_name;
	private String user_account;
	private int user_bankname;
	private int user_balance;
	private int user_stats;
	private String user_usedate;
	private int user_changes;
	private String user_memo;
	
	public int getSeq_user() {
		return seq_user;
	}
	public void setSeq_user(int seq_user) {
		this.seq_user = seq_user;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_account() {
		return user_account;
	}
	public void setUser_account(String user_account) {
		this.user_account = user_account;
	}
	public int getUser_bankname() {
		return user_bankname;
	}
	public void setUser_bankname(int user_bankname) {
		this.user_bankname = user_bankname;
	}
	public int getUser_balance() {
		return user_balance;
	}
	public void setUser_balance(int user_balance) {
		this.user_balance = user_balance;
	}
	public int getUser_stats() {
		return user_stats;
	}
	public void setUser_stats(int user_stats) {
		this.user_stats = user_stats;
	}
	public String getUser_usedate() {
		return user_usedate;
	}
	public void setUser_usedate(String user_usedate) {
		this.user_usedate = user_usedate;
	}
	public int getUser_changes() {
		return user_changes;
	}
	public void setUser_changes(int user_changes) {
		this.user_changes = user_changes;
	}
	public String getUser_memo() {
		return user_memo;
	}
	public void setUser_memo(String user_memo) {
		this.user_memo = user_memo;
	}
	

}
