package com.hy.Chat.DTO;

public class ChatDTO {
	private int chatIdx;
	private String chatName;
	private String chatPassword;
	private String chatLeader;
	private int chatSecret;
	private int chatHead;
	private String chatLog;
	public String getChatName() {
		return chatName;
	}
	public void setChatName(String chatName) {
		this.chatName = chatName;
	}
	public String getChatPassword() {
		return chatPassword;
	}
	public void setChatPassword(String chatPassword) {
		this.chatPassword = chatPassword;
	}
	public String getChatLeader() {
		return chatLeader;
	}
	public void setChatLeader(String chatLeader) {
		this.chatLeader = chatLeader;
	}
	public int getChatSecret() {
		return chatSecret;
	}
	public void setChatSecret(int chatSecret) {
		this.chatSecret = chatSecret;
	}
	public int getChatHead() {
		return chatHead;
	}
	public void setChatHead(int chatHead) {
		this.chatHead = chatHead;
	}
	public String getChatLog() {
		return chatLog;
	}
	public void setChatLog(String chatLog) {
		this.chatLog = chatLog;
	}
	public int getChatIdx() {
		return chatIdx;
	}
	public void setChatIdx(int chatIdx) {
		this.chatIdx = chatIdx;
	}

	
	
}
