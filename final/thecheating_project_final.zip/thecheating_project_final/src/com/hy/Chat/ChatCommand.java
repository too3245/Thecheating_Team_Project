package com.hy.Chat;

public class ChatCommand {

	private String chatName;
	private String chatPassword;
	private int chatSecret;
	private String chatHuman;
	public String getChatName() {
		return chatName;
	}
	public void setChatName(String chatName) {
		this.chatName = chatName;
	}
	public String getChatPassword() {
		return chatPassword;
	}
	public void setChatPassword(String chatPassword) {
		this.chatPassword = chatPassword;
	}
	public int getChatSecret() {
		return chatSecret;
	}
	public void setChatSecret(int chatSecret) {
		this.chatSecret = chatSecret;
	}
	public String getChatHuman() {
		return chatHuman;
	}
	public void setChatHuman(String chatHuman) {
		this.chatHuman = chatHuman;
	} 
	
	
}
