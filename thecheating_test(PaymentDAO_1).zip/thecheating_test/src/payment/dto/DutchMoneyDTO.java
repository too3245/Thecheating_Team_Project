package payment.dto;

public class DutchMoneyDTO {
	
	private int chat_leader;
	private String leader_account;
	private int leader_banknum;
	private String sender;
	private int deposit;
	private String depo_date;
	private int Payment;
	private String pay_date;
	private String create_date;
	
	public int getChat_leader() {
		return chat_leader;
	}
	public void setChat_leader(int chat_leader) {
		this.chat_leader = chat_leader;
	}
	public String getLeader_account() {
		return leader_account;
	}
	public void setLeader_account(String leader_account) {
		this.leader_account = leader_account;
	}
	public int getLeader_banknum() {
		return leader_banknum;
	}
	public void setLeader_banknum(int leader_banknum) {
		this.leader_banknum = leader_banknum;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public int getDeposit() {
		return deposit;
	}
	public void setDeposit(int deposit) {
		this.deposit = deposit;
	}
	public String getDepo_date() {
		return depo_date;
	}
	public void setDepo_date(String depo_date) {
		this.depo_date = depo_date;
	}
	public int getPayment() {
		return Payment;
	}
	public void setPayment(int payment) {
		Payment = payment;
	}
	public String getPay_date() {
		return pay_date;
	}
	public void setPay_date(String pay_date) {
		this.pay_date = pay_date;
	}
	public String getCreate_date() {
		return create_date;
	}
	public void setCreate_date(String create_date) {
		this.create_date = create_date;
	}
	public int getStats() {
		return stats;
	}
	public void setStats(int stats) {
		this.stats = stats;
	}
	private int stats;
}
